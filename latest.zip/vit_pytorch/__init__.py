from vit_pytorch.vit import ViT
from vit_pytorch.vit3d import ViT3d
from vit_pytorch.dino import Dino
